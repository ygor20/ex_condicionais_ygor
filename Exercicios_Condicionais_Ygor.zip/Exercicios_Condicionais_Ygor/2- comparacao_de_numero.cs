﻿

Console.WriteLine ("Digite o primeiro número.");
int num1 = int.Parse (Console.ReadLine());

Console.WriteLine ("Digite o segundo número.");
int num2 = int.Parse (Console.ReadLine());

if (num1 > num2)
{
    Console.WriteLine ("O Primeiro número é maior.");
}

else if (num1 < num2)

{
    Console.WriteLine ("O Segundo número é maior.");

}

else 
{
    Console.WriteLine ("Os números são iguais.");
}

