﻿
Console.WriteLine ("Digite um número de 1 a 7.");
int num1 = int.Parse (Console.ReadLine());

if (num1 == 1)

{
    Console.WriteLine ("Domingo");
}

else if (num1 == 2)

{
    Console.WriteLine ("Segunda-feira");
}

else if (num1 == 3)

{
    Console.WriteLine ("Terça-feira");
}

else if (num1 == 4)

{
    Console.WriteLine ("Quarta-feira");
}

else if (num1 == 5)

{
    Console.WriteLine ("Quinta-feira");
}

else if (num1 == 6)

{
    Console.WriteLine ("Sexta-feira");
}

else if (num1 == 7)

{
    Console.WriteLine ("Sábado");
}

else 
{
    Console.WriteLine ("Número inválido.Digite um número de 1 a 7.");
}

