﻿


Console.WriteLine ("Por favor, digite sua nota");
int nota = int.Parse (Console.ReadLine());

if (nota >= 6)
{
Console.WriteLine("Aluno aprovado!");
}

else
{
    Console.WriteLine("Aluno reprovado!");
}


