﻿

Console.WriteLine("Digite um número!");
int num1 = int.Parse(Console.ReadLine());

if (num1 <0)
{
    Console.WriteLine("Numero negativo");
}

else if (num1 >0)
{
    Console.WriteLine ("Numero positivo!");

}
else
{
    Console.WriteLine ("Numero zero");
}